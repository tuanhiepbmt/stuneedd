export default {
  CLIENT_ROUTE: '/',
  ADMIN_ROUTE: '/admin',
}