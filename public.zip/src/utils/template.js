/* default path /src/views */
export default {
  LAYOUT: {
    HEADER: '_layout/header',
    FOOTER: '_layout/footer',
    PLUGINS: '_layout/plugins',
    NOT_FOUND: '_layout/not_found',
  },
};