import express from '@core/express';
import logger from '@core/logger';
import config from '@utils/config';

express.listen(config.port, () => {
  logger.info(`🚀🚀🚀 Listening on port ${config.port}...`);
})