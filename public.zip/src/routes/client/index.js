import commonRouter from '@routes/client/common';
import productRouter from '@routes/client/product';

const routes = [
  commonRouter,
  productRouter,
];

export default routes;