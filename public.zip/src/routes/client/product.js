import express from 'express';

const productRoutes = express.Router();

export default productRoutes;