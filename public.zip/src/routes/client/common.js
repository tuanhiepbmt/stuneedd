import express from 'express';

const commonRoutes = express.Router();
commonRoutes.get('/home', (request, response, next) => {
  response.render('client/common/home');
});

commonRoutes.get('/contacts', (request, response, next) => {
  response.render('client/common/contacts');
});

export default commonRoutes;